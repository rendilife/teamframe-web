SEKTOR NULA Launcher v2.0 (redesign)
====================================

1. Unzip and run SEKTOR_NULA_Launcher.exe.
2. Windows may show "Windows protected your PC" (the exe is not code-signed).
   Click "More info", then "Run anyway".
3. Install and update work exactly like the original launcher: same server, same folder
   (C:\Program Files\SEKTOR NULA), same verification and backups. Windows asks for
   administrator approval when installing or updating.
   An existing installation from the original launcher is recognised automatically.

SHA-256 of SEKTOR_NULA_Launcher.exe:
b85a1e1eba9142a8d6d4e4306c08e2a14536486ca3324c0b3823b525f56ffd96
